<?php ob_start();?>
Texto
<?php require(__DIR__."/convertir_dompdf.php"); ?>