<header>
    <center>
        <h1>Secuencias de Aprendizaje</h1>
    </center>
</header>