<footer style="bottom:0;position:fixed;right:0px;background-color:#fff;width:100%" class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0
        </div>
        <strong>Development House <a href="">Secuencias de Aprendizaje</a>.</strong>
</footer>